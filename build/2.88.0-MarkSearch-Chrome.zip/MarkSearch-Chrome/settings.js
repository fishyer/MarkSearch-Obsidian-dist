/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!*************************!*\
  !*** ./src/settings.ts ***!
  \*************************/
// 从chrome.storage.local改成从window.localStorage获取数据,不能这么做，因为这样只能在插件的background.js中获取到，content_script.js中获取不到
// 读取已有的配置项并填充输入框
chrome.storage.local.get(null, function (data) {
    console.log("data: " + data);
    const { repoName, apiKey } = data;
    if (repoName) {
        document.getElementById("repoName").value = repoName;
    }
    if (apiKey) {
        document.getElementById("apiKey").value = apiKey;
    }
});
// 保存用户输入的配置项
document.getElementById("saveBtn").addEventListener("click", function () {
    const repoName = document.getElementById("repoName")
        .value;
    const apiKey = document.getElementById("apiKey").value;
    // 使用Chrome的键值对存储功能保存配置项
    chrome.storage.local.set({ repoName: repoName, apiKey: apiKey }, function () {
        console.log("已保存本地配置项");
        alert("已保存本地配置项");
        window.close();
    });
});

/******/ })()
;
//# sourceMappingURL=settings.js.map