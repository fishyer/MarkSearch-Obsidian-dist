/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/
/// <reference types="chrome"/>
console.log('Hello, from the background!');
// const { WorkFlowy } = require("workflowy");
// import { on } from 'process';
// import openUrl from 'open';
// openUrl('https://v.qq.com/x/page/l0550bf7eei.html');
// import { myUtilFunction } from './util';
// debugger;  // 这将会暂停代码，使你可以在开发者工具中检查它
// Now you can use myUtilFunction in your code.
// debugger;
// const result=myUtilFunction(1,2);
// console.log("result: "+result);
// 事件流转：点击图标、系统方法 -> chrome书签变化 -> 插件图标数字变化和颜色变化
// 监听书签变化事件
chrome.bookmarks.onCreated.addListener(onBookmarkChanged);
chrome.bookmarks.onRemoved.addListener(onBookmarkChanged);
chrome.bookmarks.onCreated.addListener(function (bookmarkId) {
    console.log("新增书签：", bookmarkId); //179516
    // 通过书签id找到指定的书签，获取title和url
    chrome.bookmarks.get(bookmarkId, function (bookmarks) {
        if (bookmarks.length > 0) {
            var bookmark = bookmarks[0];
            console.log("书签标题：", bookmark.title);
            console.log("书签URL：", bookmark.url);
            // 判断是否在parentId为2的书签下
            chrome.bookmarks.get(bookmarkId, function (bookmarks) {
                if (bookmarks.length > 0) {
                    var bookmark = bookmarks[0];
                    if (bookmark.parentId === "2") {
                        // 新增书签在parentId为2的书签下，执行相关操作
                        console.log("新增书签在parentId为2的书签下");
                        markHtml(bookmark.url, bookmark.title, bookmarkId);
                    }
                }
            });
        }
        else {
            console.log("未找到指定的书签");
        }
    });
});
chrome.bookmarks.onRemoved.addListener(function (bookmarkId) {
    console.log("移除书签：", bookmarkId);
});
// 监听选项卡切换事件，更新图标颜色
chrome.tabs.onActivated.addListener(function (activeInfo) {
    initCurrentTabIconStatus();
});
function onDoubleClick(tab) {
    addBookmark(tab);
    // //给content_script发送消息
    // chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    //     var tab = tabs[0];
    //     var url=tab.url;
    //     console.log("onDoubleClick url: "+url);
    //     if(url.includes("youtube.com")){
    //         const downieUrl=`downie://XUOpenLink?url=${url}`
    //         console.log("onDoubleClick youtube downieUrl: "+downieUrl);
    //         chrome.tabs.create({url: downieUrl});
    //     }
    //     chrome.tabs.sendMessage(tab.id, { action: "forceSaveHtml"}, function (response) {
    //         console.log(response);
    //         onSingleClick(tab)
    //     });
    // });
}
// 监听插件图标点击事件
function onSingleClick(tab) {
    chrome.bookmarks.search({ url: tab.url }, function (results) {
        if (results.length > 0) {
            // 书签已存在，删除书签并更改图标为 gray.icon
            chrome.bookmarks.remove(results[0].id);
        }
        else {
            // 书签不存在，添加书签并更改图标为 blue.icon, parentId: "2" 为其它书签栏
            chrome.bookmarks.create({
                parentId: "2",
                title: tab.title,
                url: tab.url,
            });
            // 添加书签后，关闭当前tab
            // chrome.tabs.remove(tab.id);
        }
    });
}
;
let clickCounter = 0;
let singleClickTimer;
chrome.browserAction.onClicked.addListener(function (tab) {
    clickCounter++;
    // 如果是第一次单击
    if (clickCounter === 1) {
        // 设置一个定时器，当在500ms内没有第二次点击时，执行单击事件的相关操作
        singleClickTimer = setTimeout(function () {
            clickCounter = 0;
            console.log('Single Click Event');
            onSingleClick(tab);
        }, 500);
    }
    // 如果在500ms内第二次点击，执行一个双击事件的相关操作
    else if (clickCounter === 2) {
        clearTimeout(singleClickTimer);
        clickCounter = 0;
        console.log('Double Click Event');
        onDoubleClick(tab);
    }
});
// 监听Tab加载完成事件，更新图标颜色
// 它会在每次页面加载完成时触发，包括页面刷新、打开新页面、打开新标签页等
// loading -> undefined -> complete
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    console.log("changeInfo.status: " + changeInfo.status);
    initCurrentTabIconStatus();
    //当加载完成时，打印出页面的title和url
    if (changeInfo.status == "complete") {
        console.log(`tab.complete: ${tab.title} ${tab.title}`);
    }
});
// 创建右键菜单
// chrome.contextMenus.create({
//     "title": "收藏后关闭当前tab",
//     "id": "markClose",
//     "contexts": ["browser_action"]
// });
// chrome.contextMenus.create({
//     "title": "快速添加书签呀",
//     "id": "addBookmark",
//     "contexts": ["browser_action"]
// });
chrome.contextMenus.create({
    "title": "插件必填设置",
    "id": "settings",
    "contexts": ["browser_action"]
});
chrome.contextMenus.create({
    "title": "暂停自动剪藏",
    "id": "needClip",
    "contexts": ["browser_action"]
});
chrome.contextMenus.create({
    "title": "暂停自动搜索",
    "id": "needSearch",
    "contexts": ["browser_action"]
});
chrome.contextMenus.create({
    "title": "折叠搜索结果",
    "id": "needFold",
    "contexts": ["browser_action"]
});
chrome.contextMenus.create({
    "title": "打开搜索条目方式-当前localhost",
    "id": "openItem",
    "contexts": ["browser_action"]
});
chrome.contextMenus.create({
    "title": "搜索方式-当前文件名搜索",
    "id": "searchType",
    "contexts": ["browser_action"]
});
// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener(function (info, tab) {
    switch (info.menuItemId) {
        case "baidu":
            chrome.tabs.create({
                url: "https://www.baidu.com/"
            });
            break;
        case "google":
            chrome.tabs.create({
                url: "https://www.google.com/"
            });
            break;
        case "delete":
            // prepareDeleteBookmark();
            break;
        case "addBookmark":
            addBookmark(tab);
            break;
        case "settings":
            openSettings();
            break;
        case "needClip":
            changeNeedClip();
            break;
        case "needSearch":
            changeNeedSearch();
            break;
        case "needFold":
            changeNeedFold();
            break;
        case "openItem":
            changeOpenItem();
            break;
        case "markClose":
            changeMarkClose();
            break;
        case "searchType":
            changeSearchType();
            break;
        default:
            break;
    }
});
var needSearch = true;
var needClip = true;
var needFold = true;
var searchType = "fileName";
var openItem = "localhost";
var markClose = false;
chrome.storage.local.get(null, function (data) {
    console.log('MarkSearch.data: ' + JSON.stringify(data));
    needClip = data.needClip;
    needSearch = data.needSearch;
    needFold = data.needFold;
    searchType = data.searchType;
    openItem = data.openItem;
    markClose = data.markClose;
    if (needClip === undefined || needClip === null || needClip === true) {
        chrome.contextMenus.update("needClip", { "title": "暂停自动剪藏" });
    }
    else {
        chrome.contextMenus.update("needClip", { "title": "恢复自动剪藏" });
    }
    if (needSearch === undefined || needSearch === null || needSearch === true) {
        chrome.contextMenus.update("needSearch", { "title": "暂停自动搜索" });
    }
    else {
        chrome.contextMenus.update("needSearch", { "title": "恢复自动搜索" });
    }
    if (needFold === undefined || needFold === null || needFold === true) {
        chrome.contextMenus.update("needFold", { "title": "展开搜索结果" });
    }
    else {
        chrome.contextMenus.update("needFold", { "title": "折叠搜索结果" });
    }
    if (searchType === undefined || searchType === null || searchType === "fileName") {
        chrome.contextMenus.update("searchType", { "title": "切换搜索方式-当前文件名搜索" });
    }
    else {
        chrome.contextMenus.update("searchType", { "title": "切换搜索方式-当前全文搜索" });
    }
    if (openItem === undefined || openItem === null || openItem === "localhost") {
        chrome.contextMenus.update("openItem", { "title": "打开搜索条目方式-当前localhost" });
    }
    else {
        chrome.contextMenus.update("openItem", { "title": "打开搜索条目方式-当前obsidian" });
    }
    if (markClose === undefined || markClose === null || markClose === false) {
        chrome.contextMenus.update("markClose", { "title": "收藏后关闭当前tab" });
    }
    else {
        chrome.contextMenus.update("markClose", { "title": "收藏后不关闭当前tab" });
    }
});
function addBookmark(tab) {
    chrome.bookmarks.search({ url: tab.url }, function (results) {
        if (results.length > 0) {
            // 书签已存在，删除书签并更改图标为 gray.icon
            chrome.bookmarks.remove(results[0].id);
        }
        else {
            // 书签不存在，添加书签并更改图标为 blue.icon, parentId: "2" 为书签栏
            chrome.bookmarks.create({
                parentId: "1",
                title: tab.title,
                url: tab.url,
            });
        }
    });
}
function changeNeedClip() {
    if (needClip) {
        //fasle
        needClip = !needClip;
        chrome.storage.local.set({ 'needClip': needClip }, function () {
            console.log('已保存本地配置项 needClip=', needClip);
            chrome.contextMenus.update("needClip", { "title": "恢复自动剪藏" });
        });
    }
    else {
        //true
        needClip = !needClip;
        chrome.storage.local.set({ 'needClip': needClip }, function () {
            console.log('已保存本地配置项 needClip=', needClip);
            chrome.contextMenus.update("needClip", { "title": "暂停自动剪藏" });
        });
    }
}
function changeNeedSearch() {
    if (needSearch) {
        needSearch = !needSearch;
        chrome.storage.local.set({ 'needSearch': needSearch }, function () {
            console.log('已保存本地配置项 needSearch=', needSearch);
            chrome.contextMenus.update("needSearch", { "title": "恢复自动搜索" });
        });
    }
    else {
        needSearch = !needSearch;
        chrome.storage.local.set({ 'needSearch': needSearch }, function () {
            console.log('已保存本地配置项 needSearch=', needSearch);
            chrome.contextMenus.update("needSearch", { "title": "暂停自动搜索" });
        });
    }
}
// true : 展开搜索结果 
// false ： 折叠搜索结果
function changeNeedFold() {
    if (needFold) {
        //fasle
        needFold = !needFold;
        chrome.storage.local.set({ 'needFold': needFold }, function () {
            console.log('已保存本地配置项 needFold=', needFold);
            chrome.contextMenus.update("needFold", { "title": "折叠搜索结果" });
        });
    }
    else {
        //true
        needFold = !needFold;
        chrome.storage.local.set({ 'needFold': needFold }, function () {
            console.log('已保存本地配置项 needFold=', needFold);
            chrome.contextMenus.update("needFold", { "title": "展开搜索结果" });
        });
    }
}
function changeSearchType() {
    if (searchType == null || searchType == "fileName") {
        searchType = "content";
        chrome.storage.local.set({ 'searchType': searchType }, function () {
            console.log('已保存本地配置项 searchType=', searchType);
            chrome.contextMenus.update("searchType", { "title": "切换搜索方式-当前全文搜索" });
        });
    }
    else {
        searchType = "fileName";
        chrome.storage.local.set({ 'searchType': searchType }, function () {
            console.log('已保存本地配置项 searchType=', searchType);
            chrome.contextMenus.update("searchType", { "title": "切换搜索方式-当前文件名搜索" });
        });
    }
}
// TODO 以后再支持打开原始网页
function changeOpenItem() {
    if (openItem == null || openItem == "localhost") {
        openItem = "obsidian";
        chrome.storage.local.set({ 'openItem': openItem }, function () {
            console.log('已保存本地配置项 openItem=', openItem);
            chrome.contextMenus.update("openItem", { "title": "打开搜索条目方式-当前obsidian" });
        });
    }
    else if (openItem == "obsidian") {
        openItem = "localhost";
        chrome.storage.local.set({ 'openItem': openItem }, function () {
            console.log('已保存本地配置项 openItem=', openItem);
            chrome.contextMenus.update("openItem", { "title": "打开搜索条目方式-当前localhost" });
        });
    }
    // }else{
    //     openItem = "localhost"
    //     chrome.storage.local.set({ 'openItem': openItem }, function () {
    //         console.log('已保存本地配置项 openItem=', openItem);
    //         chrome.contextMenus.update("openItem", { "title": "打开搜索条目方式-当前localhost" });
    //     });
    // }
}
// 监听自定义消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.action == "openSettings") {
        openSettings();
        sendResponse("Function executed successfully!");
    }
});
// 监听书签树变化事件
function onBookmarkChanged() {
    initBadge();
    initCurrentTabIconStatus();
}
// 初始化当前活动的tab的图标颜色
function initCurrentTabIconStatus() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var tab = tabs[0];
        chrome.bookmarks.search({ url: tab.url }, function (results) {
            if (results.length > 0) {
                chrome.browserAction.setIcon({ path: "icons/blue.png" });
            }
            else {
                chrome.browserAction.setIcon({ path: "icons/gray.png" });
            }
        });
    });
}
// 初始化角标
function initBadge() {
    chrome.bookmarks.getTree(function (bookmarks) {
        var bookmarkCount = countBookmarks(bookmarks);
        chrome.browserAction.setBadgeText({ text: bookmarkCount.toString() });
    });
}
// 计算书签数量
function countBookmarks(bookmarks) {
    var count = 0;
    for (var i = 0; i < bookmarks.length; i++) {
        count++;
        if (bookmarks[i].children) {
            count += countBookmarks(bookmarks[i].children);
        }
    }
    return count;
}
function openSettings() {
    chrome.tabs.create({
        url: chrome.extension.getURL(`settings.html`)
    });
}
//通过mark接口保存网页
function markHtml(url, title, bookmarkId) {
    //给content_script发送消息
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        var tab = tabs[0];
        chrome.tabs.sendMessage(tab.id, { action: "markHtml", bookmarkId: bookmarkId }, function (response) {
            console.log(response);
            // 添加书签后，关闭当前tab
            console.log("收藏后关闭当前tab", markClose);
            if (markClose) {
                // 休息3秒，再关闭tab
                setTimeout(function () {
                    chrome.tabs.remove(tab.id);
                }, 1000);
            }
        });
    });
}
initBadge();
initCurrentTabIconStatus();
chrome.commands.onCommand.addListener(function (command) {
    switch (command) {
        case 'performAction1':
            // 执行操作1的相关代码
            console.log('Performing action 1');
            // 获取当前的tab
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                var tab = tabs[0];
                onSingleClick(tab);
            });
            break;
        case 'performAction2':
            // 执行操作2的相关代码
            console.log('Performing action 2');
            // 获取当前的tab
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
                var tab = tabs[0];
                onDoubleClick(tab);
            });
            break;
        // 可以添加更多的命令和相应的操作
    }
});
function changeMarkClose() {
    if (markClose) {
        //fasle
        markClose = !markClose;
        chrome.storage.local.set({ 'markClose': markClose }, function () {
            console.log('已保存本地配置项 markClose=', markClose);
            chrome.contextMenus.update("markClose", { "title": "收藏后关闭当前tab" });
        });
    }
    else {
        //true
        markClose = !markClose;
        chrome.storage.local.set({ 'markClose': markClose }, function () {
            console.log('已保存本地配置项 markClose=', markClose);
            chrome.contextMenus.update("markClose", { "title": "收藏后不关闭当前tab" });
        });
    }
}

/******/ })()
;
//# sourceMappingURL=background.js.map