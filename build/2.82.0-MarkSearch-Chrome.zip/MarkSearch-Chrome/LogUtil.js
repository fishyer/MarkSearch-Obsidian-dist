/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************!*\
  !*** ./src/LogUtil.ts ***!
  \************************/
// import moment from 'moment';
// // import { FileHandler } from './FileHandler'; // 假设你自己实现了一个文件处理器
// class Logger {
//   private static instance: Logger;
//   private logLevel: string;
//   private fileHandler: FileHandler;
//   private constructor() {
//     this.logLevel = 'info'; // 默认日志级别为info
//     this.fileHandler = {} as FileHandler; // 默认为空对象，需要在实例化Logger时设置fileHandler
//   }
//   public static getInstance(): Logger {
//     if (!Logger.instance) {
//       Logger.instance = new Logger();
//     }
//     return Logger.instance;
//   }
//   public setLogLevel(level: string): void {
//     this.logLevel = level.toLowerCase();
//   }
//   public setFileHandler(handler: FileHandler): void {
//     this.fileHandler = handler;
//   }
//   private async writeToFile(level: string, message: string): Promise<void> {
//     const logEntry = `[${level.toUpperCase()}] ${message}\n`;
//     const date = moment().format('YYYY-MM-DD'); // 使用 Moment.js 格式化日期
//     const logFile = `logs_${date}.txt`; // 拼接日志文件名
//     try {
//       await this.fileHandler.writeFile(logFile, logEntry); // 使用异步的文件写入方法写入日志
//     } catch (error) {
//       console.error(`[ERROR] Failed to write to file: ${error}`);
//     }
//   }
//   public debug(message: string): void {
//     if (this.logLevel === 'debug') {
//       console.debug(`[DEBUG] ${message}`);
//       this.writeToFile('debug', message);
//     }
//   }
//   public info(message: string): void {
//     if (this.logLevel === 'debug' || this.logLevel === 'info') {
//       console.info(`[INFO] ${message}`);
//       this.writeToFile('info', message);
//     }
//   }
//   public warn(message: string): void {
//     if (this.logLevel === 'debug' || this.logLevel === 'info' || this.logLevel === 'warn') {
//       console.warn(`[WARN] ${message}`);
//       this.writeToFile('warn', message);
//     }
//   }
//   public error(message: string): void {
//     console.error(`[ERROR] ${message}`);
//     this.writeToFile('error', message);
//   }
// }
// export default Logger;

/******/ })()
;
//# sourceMappingURL=LogUtil.js.map