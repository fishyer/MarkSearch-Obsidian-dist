/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************!*\
  !*** ./src/test_wf.ts ***!
  \************************/
// import  get_all_count from "./wf_client";
// async function someFunction() {
//   const count = await get_all_count();
//   console.log(count);
// }
// someFunction();

/******/ })()
;
//# sourceMappingURL=test_wf.js.map