/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/uuid/dist/esm-browser/native.js":
/*!******************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/native.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  randomUUID
});

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/regex.js":
/*!*****************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/regex.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/rng.js":
/*!***************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/rng.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ rng)
/* harmony export */ });
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
  // lazy load so that environments that need to polyfill have a chance to do so
  if (!getRandomValues) {
    // getRandomValues needs to be invoked in a context where "this" is a Crypto implementation.
    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);

    if (!getRandomValues) {
      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
    }
  }

  return getRandomValues(rnds8);
}

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/stringify.js":
/*!*********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/stringify.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   unsafeStringify: () => (/* binding */ unsafeStringify)
/* harmony export */ });
/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ "./node_modules/uuid/dist/esm-browser/validate.js");

/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */

const byteToHex = [];

for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 0x100).toString(16).slice(1));
}

function unsafeStringify(arr, offset = 0) {
  // Note: Be careful editing this code!  It's been tuned for performance
  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

function stringify(arr, offset = 0) {
  const uuid = unsafeStringify(arr, offset); // Consistency check for valid UUID.  If this throws, it's likely due to one
  // of the following:
  // - One or more input array values don't map to a hex octet (leading to
  // "undefined" in the uuid)
  // - Invalid input values for the RFC `version` or `variant` fields

  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__["default"])(uuid)) {
    throw TypeError('Stringified UUID is invalid');
  }

  return uuid;
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (stringify);

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/v4.js":
/*!**************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/v4.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _native_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./native.js */ "./node_modules/uuid/dist/esm-browser/native.js");
/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rng.js */ "./node_modules/uuid/dist/esm-browser/rng.js");
/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stringify.js */ "./node_modules/uuid/dist/esm-browser/stringify.js");




function v4(options, buf, offset) {
  if (_native_js__WEBPACK_IMPORTED_MODULE_0__["default"].randomUUID && !buf && !options) {
    return _native_js__WEBPACK_IMPORTED_MODULE_0__["default"].randomUUID();
  }

  options = options || {};
  const rnds = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_1__["default"])(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    offset = offset || 0;

    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }

    return buf;
  }

  return (0,_stringify_js__WEBPACK_IMPORTED_MODULE_2__.unsafeStringify)(rnds);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v4);

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/validate.js":
/*!********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/validate.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _regex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regex.js */ "./node_modules/uuid/dist/esm-browser/regex.js");


function validate(uuid) {
  return typeof uuid === 'string' && _regex_js__WEBPACK_IMPORTED_MODULE_0__["default"].test(uuid);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validate);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");

console.log("Hello, from a content script!");
// 获取当前页面的URL
const currentUrl = document.location.href;
console.log("当前页面的URL：" + currentUrl);
// 检查本机存储是否设置
let isShowSettingTip = window.localStorage.getItem("isShowSettingTip");
console.log("isShowSettingTip: " + isShowSettingTip);
//如果当前页面正则匹配Google搜索页面
if (currentUrl.match(/https:\/\/(www.)?google.com\/search/)) {
    console.log("当前页面是Google搜索页面");
    //找到#taw标签并隐藏掉，这是谷歌的网页顶部广告
    const taw = document.querySelector("#taw");
    if (taw) {
        taw.style.display = "none";
    }
    let keyword = window.location.search.match(/q=([^&]+)/)[1];
    keyword = decodeURIComponent(keyword);
    mainFlow(keyword, "google");
} //如果当前页面正则匹配百度搜索页面
else if (currentUrl.match(/https:\/\/(www.)?baidu.com\/s/)) {
    console.log("当前页面是百度搜索页面");
    const params = new URLSearchParams(new URL(currentUrl).search);
    const question = params.get("wd") || params.get("word");
    console.log("question: ", question);
    mainFlow(question, "baidu");
}
// 如果当前页面正则匹配youtube或bilibili,就自动用Downie下载它到指定的文件夹
else if (currentUrl.includes("youtube.com")) {
    console.log("当前页面是Youtube页面");
}
// 如果当前页面正则匹配localhost:10086/render，就直接跳过
else if (currentUrl.match(/http:\/\/localhost:10086\/render/)) {
    console.log("当前页面是Obsidian渲染页面");
}
else {
    console.log("当前页面不是搜索页面");
    // 非搜索页面，页面加载完成后，就去调用本地的save接口，保存页面到本地
    getChromeStorageLocal((storage) => {
        // 如果需要剪藏，就调用save接口
        const needClipStatus = checkStorageKey(storage.needClip, true);
        if (needClipStatus) {
            window.onload = function () {
                requestSaveHtml();
            };
        }
    });
}
function requestSaveHtml(checkCache = true) {
    const { title } = document;
    const url = window.location.href;
    const html = document.documentElement.outerHTML;
    console.log(`页面加载完成：${title} ${url} ${html.length}`);
    const data = {
        title: title,
        url: url,
        html: html,
        checkCache: checkCache,
    };
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:10086/save");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === XMLHttpRequest.DONE) {
            console.log(this.responseText);
        }
    });
    xhr.send(JSON.stringify(data));
}
function requestMarkHtml(bookmarkId) {
    const { title } = document;
    const url = window.location.href;
    const html = document.documentElement.outerHTML;
    console.log(`requestMarkHtml: ${title} ${url} ${html.length} ${bookmarkId}`);
    const data = {
        title: title,
        url: url,
        html: html,
        bookmarkId: bookmarkId,
    };
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "http://localhost:10086/mark");
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === XMLHttpRequest.DONE) {
            console.log(this.responseText);
        }
    });
    xhr.send(JSON.stringify(data));
    // addOmnivore(url, title);
}
function addOmnivore(url, title) {
    // TODO 生成一个uuid
    var url_uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])();
    console.log("addOmnivore: ", title, url, url_uuid);
    // WARNING: For POST requests, body is set to null by browsers.
    // var data = JSON.stringify({
    //   query:
    //     "mutation SaveUrl($input: SaveUrlInput!) { saveUrl(input: $input) { ... on SaveSuccess { url clientRequestId } ... on SaveError { errorCodes message } } }",
    //   variables: {
    //     input: {
    //       clientRequestId: url_uuid,
    //       source: "api",
    //       url: url,
    //     },
    //   },
    // });
    // var xhr = new XMLHttpRequest();
    // xhr.withCredentials = true;
    // xhr.addEventListener("readystatechange", function () {
    //   if (this.readyState === 4) {
    //     console.log(this.responseText);
    //   }
    // });
    // xhr.open("POST", "https://cors-anywhere.herokuapp.com/https://api-prod.omnivore.app/api/graphql");
    // xhr.setRequestHeader("authorization", "5453e79e-0b85-44e2-9827-fb5476ab1c7c");
    // xhr.setRequestHeader("User-Agent", "Apifox/1.0.0 (https://apifox.com)");
    // xhr.setRequestHeader("content-type", "application/json");
    // xhr.setRequestHeader("Accept", "*/*");
    // xhr.setRequestHeader("Host", "api-prod.omnivore.app");
    // xhr.setRequestHeader("Connection", "keep-alive");
    // xhr.send(data);
}
function mainFlow(keyword, searchPageType) {
    console.log("执行Obsidian搜索流程", keyword, searchPageType);
    //1.获取本地配置
    getChromeStorageLocal((storage) => {
        //2.获取搜索结果
        const { apiKey } = storage;
        const needSearch = checkStorageKey(storage.needSearch, true);
        const searchTypeStatus = checkStorageKey(storage.searchType, "fileName");
        console.log("执行完毕-获取本地配置: ", JSON.stringify(storage));
        // 默认是需要搜索的
        if (needSearch === null || needSearch == true) {
            let data = {};
            if (searchTypeStatus) {
                console.log("准备文件名搜索");
                data = JSON.stringify({
                    in: [
                        keyword,
                        {
                            var: "path",
                        },
                    ],
                });
            }
            else {
                console.log("准备全文搜索");
                data = JSON.stringify({
                    or: [
                        {
                            in: [
                                keyword,
                                {
                                    var: "path",
                                },
                            ],
                        },
                        {
                            in: [
                                keyword,
                                {
                                    var: "content",
                                },
                            ],
                        },
                    ],
                });
            }
            console.log(data);
            requestSearchData(apiKey, data, storage, (elapsedTime, resp) => {
                processSearchResults(keyword, searchPageType, storage, elapsedTime, resp);
                const needFoldStatus = checkStorageKey(storage.needFold, true);
                // 刚进页面时，使用默认的折叠状态
                initSearchListStatus(needFoldStatus, $(".searchList"));
                const searchTypeNode = $(".searchType");
                if (checkStorageKey(storage.searchType, "fileName")) {
                    searchTypeNode.textContent = `切换为全文搜索`;
                }
                else {
                    searchTypeNode.textContent = `切换为文件名搜索`;
                }
            });
        }
    });
}
function checkStorageKey(currentValue, expectValue) {
    if (currentValue === null ||
        currentValue === undefined ||
        currentValue === expectValue) {
        return true;
    }
    return false;
}
//生成的本地网络链接 http://localhost:10086/render?%BA%94%E5%BD%A9%E7%AC%94%E8%AE%B0.md
function getNativeWebUrl(path, repoName) {
    const targetUrl = encodeURIComponent(path);
    return `http://localhost:10086/render?targetUrl=${targetUrl}&repoName=${repoName}`;
}
//生成Obsidian链接 obsidian://open?vault=TestOb&file=%E6%9C%AA%E5%91%BD%E5%90%8D-9
function getObsidianUrl(path, repoName) {
    const vault = encodeURIComponent(repoName.trim());
    const name = encodeURIComponent(path.replace(".md", ""));
    return `obsidian://open?vault=${vault}&file=${name}`;
}
// 获取本地配置
function getChromeStorageLocal(next) {
    chrome.storage.local.get(null, function (data) {
        console.log("getChromeStorageLocal: ", data);
        const { repoName, apiKey } = data;
        if (repoName == null || repoName.trim().length == 0) {
            console.log("repoName is null");
            showSettingTip();
            return;
        }
        if (apiKey == null || apiKey.trim().length == 0) {
            console.log("apiKey is null");
            showSettingTip();
            return;
        }
        next(data);
    });
}
//弹出提醒设置仓库的提示
function showSettingTip() {
    // 同一个浏览器窗口实例，只弹出一次设置提示,防止在未配置时每次刷新页面或新建页面都弹出设置提示
    if (isShowSettingTip == null || !isShowSettingTip) {
        isShowSettingTip = true;
        window.localStorage.setItem("isCheckStorage", isShowSettingTip);
        return;
    }
    alert("请先设置仓库名", function () {
        chrome.runtime.sendMessage({
            action: "openSettings",
        }, function (response) {
            console.log(response);
        });
    });
}
//监听来自background.js的消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    console.log("content_script.js收到消息: ", request);
    if (request.action === "markHtml") {
        const { bookmarkId } = request;
        console.log("content_script.js收到消息:  bookmarkId=", bookmarkId);
        requestMarkHtml(bookmarkId);
        sendResponse("MarkHtml executed successfully!");
    }
    //强制保存，无视缓存
    if (request.action === "forceSaveHtml") {
        console.log("content_script.js收到消息:  forceSaveHtml");
        requestSaveHtml(false);
        sendResponse("forceSaveHtml executed successfully!");
    }
});
// 创建一个确认对话框
function alert(message, callback) {
    const confirmDialog = confirm(message);
    if (confirmDialog) {
        callback();
    }
}
// search接口-data
function requestSearchData(apiKey, data, storage, next) {
    // 获取当前时间，毫秒
    const start = performance.now();
    console.log("requestSearchData.data: ", apiKey, data);
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "http://127.0.0.1:27123/search/");
    xhr.setRequestHeader("accept", "application/json");
    xhr.setRequestHeader("Authorization", "Bearer " + apiKey);
    xhr.setRequestHeader("Content-Type", "application/vnd.olrapi.jsonlogic+json");
    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === XMLHttpRequest.DONE) {
            const resp = JSON.parse(xhr.responseText);
            const elapsedTime = Math.round(performance.now() - start);
            console.log("requestSearchData执行完毕: ", resp.length);
            console.log("requestSearchData.耗时: " + elapsedTime + "ms");
            console.log("requestSearchData.resp: ", resp);
            next(elapsedTime, resp);
        }
    });
    xhr.send(data);
}
// // search接口-文件名搜索
// function getSearchData(keyword, searchPageType, apiKey, repoName, next) {
//     console.log("getSearchData", keyword, apiKey, repoName);
//     // 获取当前时间，毫秒
//     const start = performance.now();
//     const data = JSON.stringify({
//         "in": [
//             keyword,
//             {
//                 "const": "path"
//             }
//         ]
//     });
//     console.log("data: " + data);
//     const xhr = new XMLHttpRequest();
//     xhr.open("POST", "http://127.0.0.1:27123/search/");
//     xhr.setRequestHeader("accept", "application/json");
//     xhr.setRequestHeader('Authorization', 'Bearer ' + apiKey);
//     xhr.setRequestHeader("Content-Type", "application/vnd.olrapi.jsonlogic+json");
//     xhr.addEventListener("readystatechange", function () {
//         if (this.readyState === XMLHttpRequest.DONE) {
//             const resp = JSON.parse(xhr.responseText);
//             const elapsedTime = Math.round(performance.now() - start);
//             console.log("getSearchData执行完毕: ", resp.length);
//             console.log("耗时: " + elapsedTime + "ms");
//             console.log("resp: ", resp);
//             next();
//         }
//     });
//     xhr.send(data);
// }
// // search接口-全文搜索
// function getFullSearchData(keyword, searchPageType, apiKey, repoName, next) {
//     console.log("getFullSearchData", keyword, apiKey, repoName);
//     // 获取当前时间，毫秒
//     const start = performance.now();
//     const data = JSON.stringify({
//         "or": [
//             {
//                 "in": [
//                     keyword,
//                     {
//                         "const": "path"
//                     }
//                 ]
//             },
//             {
//                 "in": [
//                     keyword,
//                     {
//                         "const": "content"
//                     }
//                 ]
//             }
//         ]
//     });
//     console.log("data: " + data);
//     const xhr = new XMLHttpRequest();
//     xhr.open("POST", "http://127.0.0.1:27123/search/");
//     xhr.setRequestHeader("accept", "application/json");
//     xhr.setRequestHeader('Authorization', 'Bearer ' + apiKey);
//     xhr.setRequestHeader("Content-Type", "application/vnd.olrapi.jsonlogic+json");
//     xhr.addEventListener("readystatechange", function () {
//         if (this.readyState === XMLHttpRequest.DONE) {
//             const resp = JSON.parse(xhr.responseText);
//             const elapsedTime = Math.round(performance.now() - start);
//             console.log("getFullSearchData执行完毕: ", resp.length);
//             console.log("耗时: " + elapsedTime + "ms");
//             console.log("resp: ", resp);
//             next();
//         }
//     });
//     xhr.send(data);
// }
const template = `
<!-- 第一行 -->
<div class="searchHeader" style="display: flex; justify-content: space-between;">
  <div style="display: flex; align-items: center;">
    <span class="searchCount">searchCount</span>
    <span class="searchTime">searchTime</span>
  </div>
  <span class="searchType">searchType</span>
</div>
<!-- 第二行 -->
<div>
  <ul class="searchList"/>
</div>
<div id="tooltip" class="tooltip"></div>
`;
function $(selector) {
    return document.querySelector(selector);
}
function processSearchResults(keyword, searchPageType, storage, elapsedTime, resp) {
    const { apiKey, repoName } = storage;
    console.log("processSearchResults", keyword, searchPageType, apiKey, repoName, elapsedTime, resp);
    //如果之前已经存在obsidanSearchResults，就先删除掉
    let obsidanSearchResults = document.querySelector(".obsidanSearchResults");
    if (obsidanSearchResults) {
        obsidanSearchResults.remove();
    }
    if (searchPageType === "google") {
        //找到#search的谷歌搜索标签
        const googleSearchResults = document.querySelector("#search");
        //添加obsidanSearchResults
        obsidanSearchResults = document.createElement("div");
        obsidanSearchResults.innerHTML = template;
        obsidanSearchResults.classList.add("obsidanSearchResults");
        googleSearchResults.insertAdjacentElement("beforebegin", obsidanSearchResults);
    }
    else if (searchPageType === "baidu") {
        //找到#search的百度搜索标签
        const baiduSearchResults = document.querySelector("#content_left");
        //添加obsidanSearchResults
        obsidanSearchResults = document.createElement("div");
        obsidanSearchResults.innerHTML = template;
        obsidanSearchResults.classList.add("obsidanSearchResults");
        //不加这两个的话，宽度会有问题
        obsidanSearchResults.classList.add("c-container");
        obsidanSearchResults.classList.add("new-pmd");
        baiduSearchResults.insertAdjacentElement("beforebegin", obsidanSearchResults);
    }
    else {
        console.log("searchPageType is null");
        return;
    }
    //设置背景色为#f5f5d5 淡黄色
    obsidanSearchResults.style.backgroundColor = "#f5f5d5";
    //3.显示搜索结果
    const bookmarks = [];
    console.log("processSearchResults.resp: " + resp);
    for (let i = 0; i < resp.length; i++) {
        console.log("resp[i]: " + resp[i]);
        const path = resp[i].filename;
        console.log("path: " + path);
        const title = extractFileName(path);
        const obsidianUrl = getObsidianUrl(path, repoName);
        const nativeWebUrl = getNativeWebUrl(path, repoName);
        bookmarks.push({
            path: path,
            title: title,
            obsidianUrl: obsidianUrl,
            nativeWebUrl: nativeWebUrl,
        });
    }
    console.log("bookmarks: ", bookmarks);
    const len = bookmarks.length;
    console.log("len: " + len);
    const searchHeader = $(".searchHeader");
    // 设置searchNumber，searchTime
    const searchCount = $(".searchCount");
    searchCount.textContent = ` 🔒 Obsidian搜索结果: ${len}`;
    searchCount.style.fontSize = "24px";
    const time = Math.round((elapsedTime / 1000) * 100) / 100;
    const searchTime = $(".searchTime");
    searchTime.textContent = `耗时: ${time}s`;
    searchTime.style.fontSize = "12px";
    const searchType = $(".searchType");
    //点击切换搜索方式
    searchType.addEventListener("click", function (e) {
        if (searchType.textContent === "切换为全文搜索") {
            console.log("准备全文搜索");
            const data = JSON.stringify({
                or: [
                    {
                        in: [
                            keyword,
                            {
                                const: "path",
                            },
                        ],
                    },
                    {
                        in: [
                            keyword,
                            {
                                const: "content",
                            },
                        ],
                    },
                ],
            });
            requestSearchData(apiKey, data, storage, (elapsedTime, resp) => {
                console.log("getFullSearchData-执行完毕");
                const lastDisplayStatus = $(".searchList").style.display;
                processSearchResults(keyword, searchPageType, storage, elapsedTime, resp);
                $(".searchType").textContent = `切换为文件名搜索`;
                // 刷新页面后，沿用之前的折叠状态
                $(".searchList").style.display = lastDisplayStatus;
            });
        }
        else if (searchType.textContent === "切换为文件名搜索") {
            console.log("准备文件名搜索");
            const data = JSON.stringify({
                in: [
                    keyword,
                    {
                        const: "path",
                    },
                ],
            });
            requestSearchData(apiKey, data, storage, (elapsedTime, resp) => {
                console.log("getSearchData-执行完毕");
                const lastDisplayStatus = $(".searchList").style.display;
                processSearchResults(keyword, searchPageType, storage, elapsedTime, resp);
                $(".searchType").textContent = `切换为全文搜索`;
                // 刷新页面后，沿用之前的折叠状态
                $(".searchList").style.display = lastDisplayStatus;
            });
        }
        e.stopPropagation();
    });
    //设置searchList
    const searchList = $(".searchList");
    searchList.style.display = "none";
    // const needFold=storage.needFold;
    // initSearchListStatus(needFold, searchList);
    //设置tooltip
    // const tooltip = $(".tooltip");
    // tooltip.style.display = "none";
    // const tooltip = document.createElement('div');
    // tooltip.id = "tooltip";
    // tooltip.classList.add('tooltip');
    // searchList.appendChild(tooltip);
    // document.addEventListener("mouseover", function (event) {
    //     const target = event.target;
    //     if (target.tagName === "A") {
    //         showTooltip(tooltip, obsidanSearchResults, target, bookmarks);
    //     }
    // });
    // document.addEventListener("mouseout", function (event) {
    //     const target = event.target;
    //     if (target.tagName === "A") {
    //         hideTooltip(tooltip);
    //     }
    // });
    //添加searchItem
    if (len > 0) {
        bookmarks.forEach((bookmark, index) => {
            const searchItem = document.createElement("li");
            searchItem.classList.add("searchItem");
            const openItemStatus = checkStorageKey(storage.openItem, "localhost");
            if (openItemStatus) {
                searchItem.innerHTML = `<a href="${bookmark.nativeWebUrl}" target="_blank">${index + 1}. ${bookmark.title}</a>`;
            }
            else {
                searchItem.innerHTML = `<a href="${bookmark.obsidianUrl}" target="_blank">${index + 1}. ${bookmark.title}</a>`;
            }
            searchList.appendChild(searchItem);
        });
        // 添加折叠和展开的功能
        searchHeader.addEventListener("click", function () {
            if (searchList.style.display === "none") {
                //展开状态
                searchList.style.display = "block";
                searchCount.textContent = ` 📁 Obsidian搜索结果: ${len}`;
                searchTime.textContent = `耗时: ${time}s`;
                console.log("展开状态");
            }
            else {
                // 折叠状态
                searchList.style.display = "none";
                searchCount.textContent = ` 🔒 Obsidian搜索结果: ${len}`;
                searchTime.textContent = `耗时: ${time}s`;
                console.log("折叠状态");
            }
        });
    }
    // googleSearchResults.insertAdjacentElement('beforebegin', newDiv);
}
function initSearchListStatus(needFoldStatus, searchList) {
    console.log("initSearchListStatus: ", needFoldStatus);
    if (needFoldStatus) {
        searchList.style.display = "none";
    }
    else {
        searchList.style.display = "block";
    }
}
// 从文件路径中提取文件名 不包含扩展名
// 示例： MyLogseq/topic/note-course/技术书籍-学习笔记/深入理解Android自动化测试.md --> 深入理解Android自动化测试
function extractFileName(filename) {
    console.log("filename: " + filename);
    return filename.replace(/^.*[\\/]/, "").replace(/\.[^.]+$/, "");
}
function genTooltipContent(bookmark) {
    return `<div class="tooltip-content">
    <div class="tooltip-path">${bookmark.path}</div>
    </div>`;
    //<div class="tooltip-url">${bookmark.url}</div><br/>
}
function showTooltip(tooltip, obsidanSearchResults, element, bookmarks) {
    const mTop = obsidanSearchResults.getBoundingClientRect().top;
    const { href } = element;
    for (let i = 0; i < bookmarks.length; i++) {
        console.log("showTooltip bookmarks[i].nativeWebUrl=", bookmarks[i].nativeWebUrl);
        console.log("showTooltip href=", href);
        if (bookmarks[i].nativeWebUrl == href) {
            console.log("showTooltip", i);
            tooltip.innerHTML = genTooltipContent(bookmarks[i]);
            break;
        }
    }
    tooltip.style.display = "block";
    const rect = element.getBoundingClientRect();
    //当页面向上滚动时，scrollTop的值大于0，此时需要加上scrollTop的值
    const { scrollTop } = document.documentElement;
    console.log("scrollTop: " + scrollTop);
    console.log("rect.top: " + rect.top);
    console.log("rect.height: " + rect.height);
    console.log("mTop: " + mTop);
    tooltip.style.left = rect.left + "px";
    tooltip.style.top = rect.top + rect.height + scrollTop - mTop + "px";
}
function hideTooltip(tooltip) {
    console.log("hideTooltip");
    tooltip.style.display = "none";
}

})();

/******/ })()
;
//# sourceMappingURL=content.js.map